(() => {
  'use strict';
  const C = XCircle;
  let data = {}, following = new Set(), followers = new Set();
  let scheduled = false, loaded = false, collector = null;
  let message = 'Loading saved lists…';
  const hidden = new Set();
  const threads = XCircleThreads();
  const currentAccount = () => C.profile(document.querySelector('a[data-testid="AppTabBar_Profile_Link"]')?.getAttribute('href'));
  const primary = () => document.querySelector('[data-testid="primaryColumn"]');
  const navigation = XCircleNavigation({
    location,
    isActive: () => loaded && data.mode && data.mode !== 'off' && currentAccount() === data.account && C.ready(data.mode, data[C.key(data.account, 'following')], data[C.key(data.account, 'followers')]),
    posts: () => primary()?.querySelectorAll('article[data-testid="tweet"]') || []
  });
  function restore() {
    threads.clear();
    for (const node of hidden) node.removeAttribute('data-xcircle-hidden');
    hidden.clear();
  }
  function filter() {
    scheduled = false;
    if (!loaded) return;
    navigation.beforeFilter();
    const mode = data.mode || 'off';
    const account = currentAccount();
    let reason = '';
    if (mode === 'off') reason = 'Filtering is off. Everyone is visible.';
    else if (!/^\/home\/?$/.test(location.pathname)) reason = 'Your filter applies on the Home timeline.';
    else if (!account || account !== data.account) reason = 'Filtering paused: open your saved account on X, or update the username here.';
    else if (!C.ready(mode, data[C.key(data.account, 'following')], data[C.key(data.account, 'followers')])) reason = 'Filtering paused: collect the lists required for this filter.';
    if (reason) { restore(); message = reason; navigation.afterFilter(); return; }
    const keepHidden = new Set();
    const entries = [];
    let shown = 0, unknown = 0;
    for (const article of primary()?.querySelectorAll('article[data-testid="tweet"]') || []) {
      if (article.parentElement?.closest('article[data-testid="tweet"]')) continue;
      const author = C.authorOf(article);
      const excluded = !C.allows(author, mode, following, followers);
      entries.push({ article, excluded });
      if (!author) unknown++;
      // Only collapse a cell when it contains one outer post. Avoid hiding sibling posts.
      const cell = article.closest('[data-testid="cellInnerDiv"]');
      const target = cell && cell.querySelectorAll('article[data-testid="tweet"]').length === 1 ? cell : article;
      if (excluded) {
        if (target.getAttribute('data-xcircle-hidden') !== 'true') target.setAttribute('data-xcircle-hidden', 'true');
        keepHidden.add(target);
      } else { shown++; }
    }
    for (const node of hidden) if (!keepHidden.has(node)) node.removeAttribute('data-xcircle-hidden');
    hidden.clear();
    for (const node of keepHidden) hidden.add(node);
    threads.sync(entries);
    message = `${hidden.size} hidden · ${shown} shown among loaded posts.${unknown ? ` ${unknown} unreadable author(s) left visible.` : ''}`;
    navigation.afterFilter();
  }
  function schedule() {
    if (!scheduled) { scheduled = true; setTimeout(filter, 80); }
  }
  async function refresh() {
    data = await chrome.storage.local.get(null);
    following = new Set(data[C.key(data.account, 'following')]?.handles || []);
    followers = new Set(data[C.key(data.account, 'followers')]?.handles || []);
    loaded = true;
    filter();
  }
  function startCollector() {
    if (collector || location.hash !== '#xc-collect') return;
    const match = location.pathname.match(/^\/([a-z0-9_]+)\/(following|followers)\/?$/i);
    if (!match || C.handle(match[1]) !== data.account) return;
    const owner = data.account, kind = match[2].toLowerCase(), originalPath = location.pathname;
    const found = new Set();
    let running = true, lastNew = Date.now(), started = Date.now(), finished = false;
    const host = document.createElement('div');
    host.id = 'xcircle-collector';
    host.style.cssText = 'position:fixed;z-index:2147483647;bottom:20px;right:20px;width:min(350px,calc(100vw - 40px));';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>
      :host { all: initial; } * {box-sizing:border-box} .panel {font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#172635;background:white;border:1px solid #b9c7d3;border-radius:12px;padding:18px;box-shadow:0 5px 30px #0003} h2 {font-size:17px;margin:0 0 8px} p {margin:8px 0;font-size:13px} .count {font-size:26px;font-weight:650} button {font:inherit;padding:7px 10px;background:#edf5fc;border:1px solid #b9c7d3;border-radius:5px;color:#124f82;cursor:pointer} button:disabled {opacity:.5;cursor:default} button:focus-visible,input:focus-visible {outline:2px solid #1768ac;outline-offset:3px} .actions {display:flex;gap:6px;flex-wrap:wrap;margin-top:12px} label {display:flex;align-items:flex-start;gap:7px;font-size:12px;margin-top:12px} input {margin-top:3px}
    </style><section class="panel" aria-label="X Circle list collection">
      <h2></h2><div class="count" aria-live="polite">0 collected</div>
      <p class="status" role="status">Scrolling through the list. Keep this tab visible.</p>
      <p>When scrolling stops, check the page reached the end. If X shows an error or more accounts load, continue collecting.</p>
      <label><input type="checkbox">I checked that the full list is loaded (or that this account has none).</label>
      <div class="actions"><button class="pause">Pause</button><button class="save" disabled>Save list</button><button class="cancel">Cancel</button></div>
    </section>`;
    root.querySelector('h2').textContent = `Collecting @${owner}’s ${kind}`;
    const notice = text => { root.querySelector('.status').textContent = text; };
    const pause = root.querySelector('.pause'), save = root.querySelector('.save'), check = root.querySelector('input');
    function valid() { return location.pathname === originalPath && data.account === owner && (!currentAccount() || currentAccount() === owner); }
    function collect() {
      if (finished || !valid()) return;
      const column = primary();
      // Scope to the relationship timeline, excluding sidebar recommendations.
      const region = [...(column?.querySelectorAll('section[role="region"]') || [])].find(node => node.querySelector('[data-testid="UserCell"]'));
      const timeline = region || column?.querySelector('[aria-label^="Timeline:"]');
      if (!timeline) return;
      const before = found.size;
      for (const cell of timeline.querySelectorAll('[data-testid="UserCell"]')) {
        const name = C.userOf(cell);
        if (name && name !== owner) found.add(name);
      }
      if (found.size !== before) {
        lastNew = Date.now(); check.checked = false; save.disabled = true;
        root.querySelector('.count').textContent = `${found.size.toLocaleString()} collected`;
      }
    }
    function stop(text) { running = false; pause.textContent = 'Continue'; notice(text); }
    function close() { finished = true; clearInterval(timer); observer.disconnect(); host.remove(); collector = null; history.replaceState(null, '', location.pathname + location.search); }
    pause.addEventListener('click', () => {
      if (running) stop('Paused. Scroll manually or continue collecting.');
      else { running = true; lastNew = Date.now(); started = Date.now(); check.checked = false; save.disabled = true; pause.textContent = 'Pause'; notice('Scrolling through the list. Keep this tab visible.'); }
    });
    check.addEventListener('change', () => { collect(); if (check.checked) stop('Review complete. Save to replace the previous snapshot.'); save.disabled = !check.checked; });
    save.addEventListener('click', async () => {
      if (!valid() || !check.checked || finished) return;
      collect();
      if (!check.checked) return;
      save.disabled = true;
      try {
        await chrome.storage.local.set({ [C.key(owner, kind)]: { handles: [...found].sort(), savedAt: Date.now(), reviewed: true } });
        finished = true; clearInterval(timer); observer.disconnect();
        pause.hidden = true; save.hidden = true; check.disabled = true;
        root.querySelector('.cancel').textContent = 'Close';
        notice(`Saved ${found.size.toLocaleString()} ${kind}. Choose your filter in the extension popup.`);
      } catch (error) { notice(`Could not save: ${error.message}`); save.disabled = false; }
    });
    root.querySelector('.cancel').addEventListener('click', close);
    document.documentElement.append(host);
    const observer = new MutationObserver(collect);
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['href'] });
    const timer = setInterval(() => {
      if (!valid()) { close(); return; }
      collect();
      if (!running) return;
      if (document.hidden) { lastNew = Date.now(); return; }
      if (Date.now() - lastNew > 12000) { stop('No new accounts appeared for 12 seconds. Check for the end of the list or a loading error before saving.'); return; }
      if (Date.now() - started > 15 * 60 * 1000) { stop('Paused after 15 minutes. Continue if the list has more accounts.'); return; }
      window.scrollBy({ top: Math.max(350, window.innerHeight * .65), behavior: 'instant' });
    }, 1100);
    collector = { close };
    window.scrollTo({ top: 0, behavior: 'instant' });
    collect();
  }
  chrome.runtime.onMessage.addListener((request, sender, respond) => {
    if (request.type === 'xc-status') { filter(); respond({ account: currentAccount(), message }); }
  });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local') refresh().catch(() => { restore(); }); });
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'data-testid'] });
  // X uses client-side navigation; polling also handles account switches without a reload.
  setInterval(() => { filter(); if (loaded) startCollector(); }, 1000);
  refresh().then(startCollector).catch(() => { restore(); message = 'Could not read saved lists. Reload this X tab.'; });
})();
