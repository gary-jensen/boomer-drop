/* Preserve the filtered viewport across X's client-side tweet / Back navigation. */
globalThis.XCircleNavigation = function ({ isActive, posts, location = window.location }) {
  const isHome = () => /^\/home\/?$/.test(location.pathname);
  const isTweet = path => /^\/[^/]+\/status\/\d+/.test(path);
  let lastPath = location.pathname;
  let checkpoint = null, departure = null, pending = null, frame = 0;
  let awayOnTweet = false;

  function permalink(post) {
    const header = post.querySelector('[data-testid="User-Name"]');
    for (const link of header?.querySelectorAll('a[href]') || []) {
      const path = new URL(link.getAttribute('href'), 'https://x.com').pathname;
      if (isTweet(path)) return path.toLowerCase();
    }
    return null;
  }
  function capture() {
    if (!isHome() || !isActive() || pending) return;
    let anchor = null;
    for (const post of posts()) {
      const rect = post.getBoundingClientRect();
      if (rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight) {
        const id = permalink(post);
        if (id) { anchor = { id, top: rect.top }; break; }
      }
    }
    checkpoint = { y: window.scrollY, anchor };
  }
  function cancel() {
    pending = null;
    cancelAnimationFrame(frame);
    frame = 0;
  }
  function restoreFrame() {
    frame = 0;
    if (!pending) return;
    if (!isHome() || !isActive() || performance.now() > pending.until) {
      cancel(); capture(); return;
    }
    const saved = pending.saved;
    const anchor = saved.anchor && [...posts()].find(post => permalink(post) === saved.anchor.id && post.getBoundingClientRect().height > 0);
    // Prefer a post anchor: filtering and late-loading media change absolute heights.
    // While X rebuilds its virtual list, the old Y position is a bounded fallback.
    const target = anchor ? window.scrollY + anchor.getBoundingClientRect().top - saved.anchor.top : saved.y;
    const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    if ((anchor || max >= saved.y) && Math.abs(window.scrollY - Math.max(0, target)) > 2) {
      window.scrollTo({ top: Math.max(0, target), behavior: 'instant' });
    }
    frame = requestAnimationFrame(restoreFrame);
  }
  function beforeFilter() {
    if (!isActive()) { cancel(); checkpoint = departure = null; awayOnTweet = false; }
    if (location.pathname !== lastPath) {
      if (/^\/home\/?$/.test(lastPath) && !isHome()) {
        awayOnTweet = isTweet(location.pathname);
        if (departure && performance.now() - departure.at < 2000) checkpoint = departure.saved;
        if (!awayOnTweet) checkpoint = null;
      }
      if (isHome() && !pending) { checkpoint = null; departure = null; awayOnTweet = false; }
      lastPath = location.pathname;
    }
  }
  function afterFilter() {
    if (pending) { if (!frame) frame = requestAnimationFrame(restoreFrame); }
    else capture();
  }
  // Capture before X handles the click and replaces or scrolls its Home column.
  document.addEventListener('click', event => {
    if (!isHome() || !isActive()) return;
    const post = event.target instanceof Element && event.target.closest('article[data-testid="tweet"]');
    if (!post || !post.closest('[data-testid="primaryColumn"]')) return;
    capture();
    departure = checkpoint && { saved: checkpoint, at: performance.now() };
  }, true);
  window.addEventListener('scroll', () => {
    // A queued scroll event can run after popstate but before the route observer.
    if (isHome() && lastPath === location.pathname && !pending) capture();
  }, { passive: true });
  window.addEventListener('popstate', () => {
    if (!isHome() || !isActive()) { cancel(); return; }
    // Also cover a quick open/back before the DOM observer sees the tweet route.
    const quickReturn = departure && performance.now() - departure.at < 2000;
    const saved = quickReturn ? departure.saved : checkpoint;
    if (saved && (awayOnTweet || isTweet(lastPath) || quickReturn)) {
      cancel();
      pending = { saved, until: performance.now() + 3000 };
      frame = requestAnimationFrame(restoreFrame);
    }
  });
  // Never fight an intentional user scroll or another navigation.
  for (const type of ['wheel', 'touchstart', 'pointerdown']) {
    window.addEventListener(type, cancel, { passive: true, capture: true });
  }
  window.addEventListener('keydown', event => {
    if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(event.key)) cancel();
  }, true);
  return { beforeFilter, afterFilter };
};
