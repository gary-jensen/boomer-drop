(function (root) {
  'use strict';
  const modes = ['off', 'not-following', 'mutuals', 'followers-only'];
  const reserved = new Set(['home', 'explore', 'notifications', 'messages', 'search', 'settings', 'compose', 'i', 'login', 'logout', 'signup', 'tos', 'privacy']);
  function handle(value) {
    const normalized = String(value || '').trim().replace(/^@/, '').toLowerCase();
    return /^[a-z0-9_]{1,15}$/.test(normalized) && !reserved.has(normalized) ? normalized : null;
  }
  function profile(href) {
    try {
      const url = new URL(href, 'https://x.com');
      if (!['x.com', 'www.x.com', 'twitter.com', 'www.twitter.com'].includes(url.hostname)) return null;
      const match = url.pathname.match(/^\/([a-z0-9_]+)\/?$/i);
      return match ? handle(match[1]) : null;
    } catch { return null; }
  }
  const key = (owner, kind) => `snapshot:${owner}:${kind}`;
  function ready(mode, following, followers) {
    return mode === 'off' || (modes.includes(mode) && Boolean(following) && (mode === 'not-following' || Boolean(followers)));
  }
  function allows(author, mode, following, followers) {
    if (!author || mode === 'off') return true;
    if (mode === 'not-following') return !following.has(author);
    if (mode === 'mutuals') return following.has(author) && followers.has(author);
    if (mode === 'followers-only') return followers.has(author) && !following.has(author);
    return true;
  }
  function authorOf(article) {
    // The outer post's header precedes quoted-post headers and reply/body links.
    const header = article.querySelector('[data-testid="User-Name"]');
    if (!header) return null;
    for (const link of header.querySelectorAll('a[href]')) {
      const name = profile(link.getAttribute('href'));
      if (name) return name;
    }
    return null;
  }
  function userOf(cell) {
    // An account's first profile link is its avatar/name, before any bio mentions.
    for (const link of cell.querySelectorAll('a[href]')) {
      const name = profile(link.getAttribute('href'));
      if (name) return name;
    }
    return null;
  }
  const api = { modes, handle, profile, key, ready, allows, authorOf, userOf };
  root.XCircle = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
