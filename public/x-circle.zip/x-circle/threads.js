/* Repair thread edges when filtering removes the post they originally joined. */
globalThis.XCircleThreads = function () {
  const marked = new Map();
  function connectors(article) {
    const avatar = article.querySelector('[data-testid="Tweet-User-Avatar"]');
    if (!avatar || avatar.closest('article[data-testid="tweet"]') !== article) return [];
    const siblings = [...avatar.parentElement.children];
    const avatarIndex = siblings.indexOf(avatar);
    return siblings.flatMap((node, index) => {
      // X's connectors are empty, narrow divs immediately beside the avatar.
      // Inspect this column only: video controls, quotes, icons and content can
      // also contain narrow lines, but must never be altered.
      if (node === avatar || node.tagName !== 'DIV' || node.childElementCount || node.textContent.trim() || node.hasAttribute('role') || node.hasAttribute('data-testid')) return [];
      const style = getComputedStyle(node);
      const width = parseFloat(style.width);
      const painted = style.backgroundColor !== 'transparent' && !/rgba\([^)]*,\s*0\s*\)/.test(style.backgroundColor);
      if (!(width > 0 && width <= 3 && painted)) return [];
      return [{ node, direction: index < avatarIndex ? 'before' : 'after' }];
    });
  }
  function apply(next) {
    for (const [node, attrs] of marked) {
      for (const attr of attrs) if (!next.get(node)?.has(attr)) node.removeAttribute(attr);
    }
    for (const [node, attrs] of next) {
      for (const attr of attrs) if (node.getAttribute(attr) !== 'true') node.setAttribute(attr, 'true');
    }
    marked.clear();
    for (const [node, attrs] of next) marked.set(node, attrs);
  }
  function sync(entries) {
    const next = new Map();
    function mark(node, attr) {
      if (!next.has(node)) next.set(node, new Set());
      next.get(node).add(attr);
    }
    entries.forEach((entry, index) => {
      if (entry.excluded) return;
      for (const connector of connectors(entry.article)) {
        const neighbor = entries[index + (connector.direction === 'before' ? -1 : 1)];
        if (!neighbor?.excluded) continue;
        mark(connector.node, 'data-xcircle-thread-line-hidden');
        mark(entry.article, `data-xcircle-break-${connector.direction}`);
      }
    });
    apply(next);
  }
  return { sync, clear: () => apply(new Map()) };
};
