# X Circle

A small Chrome extension for filtering the X **Home timeline** (For you and Following).

- **Only people I don’t follow:** excludes accounts in your following list.
- **Only mutuals:** includes accounts in both lists.
- **Only followers I don’t follow back:** includes followers who are absent from your following list.
- **Everyone:** turns filtering off and restores hidden posts.

## Install

1. If using the ZIP, extract it first.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode** at the top right.
4. Click **Load unpacked** and choose the `x-circle` folder containing `manifest.json`.
5. Pin X Circle from Chrome’s Extensions menu, then reload any existing X tabs.

No build tools, package installation, API key, or paid X developer account are needed.

## Update to 1.0.2

Version 1.0.2 repairs thread connectors when a parent or reply is filtered out: a connector crossing a hidden post is hidden, and a divider separates the surviving post from unrelated neighbors. Connections between adjacent visible thread posts remain intact. These changes are reversible and do not change cell height. The cause was confirmed in live X markup; the fix was validated with local DOM-adapter tests.

The scroll fix from version 1.0.1 is included. It saves the visible Home post and its viewport offset before opening a tweet. On browser Back (including X’s history-back navigation), it restores that position after filtering, with a short correction window for late layout changes. Wheel, touch, pointer, or scrolling-key input stops the correction immediately. If X has discarded the post entirely, the saved scroll offset is used when the page is tall enough.

Replace the files in the **same folder you originally loaded** with the new package, click X Circle’s **Reload** button at `chrome://extensions`, and reload your X tabs. If you loaded the project’s `outputs/x-circle` folder directly, its files are already updated. Keep the existing extension installed to preserve your saved lists and settings.

## Set up your lists

1. Sign into X and open the extension. Your username is detected from X’s profile navigation link when available. Otherwise, enter your username and click **Save**.
2. Click **Collect** beside **Following**. A new X tab opens and scrolls through your following list. Keep the tab visible.
3. When it pauses, inspect the bottom of the page. If there is a loading error or more accounts remain, resolve the error and click **Continue**. You can also pause and scroll manually; visible accounts are still collected.
4. Once you have checked that the full list loaded, tick the checkbox and click **Save list**. For an actually empty list, verify the empty-state message before saving zero accounts.
5. Repeat for **Followers**, then return to Home and select your filter in the extension popup.

“Only people I don’t follow” needs the following list. The other two filters need both. Saved lists are snapshots: collect them again after following/unfollowing people, gaining/losing followers, or changing usernames. Collecting replaces the old snapshot only when you explicitly save. Cancelling leaves the old snapshot intact. Closing or reloading a collection tab discards unsaved progress.

## How it works

The extension reads profile links from account rows on the relationship pages, normalizes usernames, and saves the two sets in `chrome.storage.local`. On Home, it reads each post’s author header and tests membership in those sets. A MutationObserver handles inserted posts and recycled DOM nodes. Settings propagate to existing X tabs.

Excluded posts are removed from the visible layout with `display: none`, preserving the DOM nodes that X’s React renderer owns. This allows immediate restoration when changing filters. The extension uses the original author of a repost and the outer author of a quote post. It does not filter by the person who reposted, or by mentions inside post text. If it cannot read an author, it leaves that post visible.

Filtering applies only to `/home`, so profile pages, search, notifications, and conversation threads remain readable. Filtering pauses if the signed-in account cannot be detected or does not match the saved username.

## Limits and troubleshooting

- A DOM-only tool can collect only accounts X renders. X may delay, truncate, or restrict relationship lists. A 12-second pause means no new usernames appeared; it is **not proof** that the list is complete. Incomplete following lists can incorrectly classify people as accounts you do not follow. Compare the collected count with your profile’s count when possible.
- The selectors target X’s current-style `UserCell`, `User-Name`, `tweet`, and `primaryColumn` elements. X can change these. The thread-connector issue was diagnosed on a signed-in X page. Automated verification uses local fixtures and DOM adapters. If collection stays at zero on a nonempty list, do not save it. If X changes its markup, the selectors will need updating.
- Very large lists take time. Collection pauses after 15 minutes; click **Continue** to keep going. Storage errors are shown rather than silently replacing a saved list.
- X virtualizes and lazily loads its timeline. Filtering only considers posts already loaded by X; it cannot force X to supply more matching posts. A restrictive filter can leave a sparse or empty viewport. Scroll to load more, or temporarily select Everyone if loading stalls.
- To remove stored relationship data, click **Clear saved lists**. This clears snapshots for all saved usernames and turns filtering off.
- After reloading/updating the extension in Chrome, reload X tabs too.

## Privacy and permissions

The only extension API permission is `storage`. Content scripts run only on `x.com` and `twitter.com` (including their `www` hosts). There is no server, analytics, remote code, cookie access, network interception, or direct X API call. X itself makes its normal page requests as you scroll. Stored usernames remain in this Chrome profile and are removed when you uninstall the extension.

## Verification

From the extension folder, run `node --test tests/core.test.cjs tests/threads.test.cjs`. All 13 Node tests passed for 1.0.2: 5 filter/input checks and 8 thread-boundary regression checks using a minimal DOM adapter based on the observed live avatar-column layout.

Run `node tests/build-browser-fixtures.cjs` to generate a local browser fixture, then open the printed `test.html` path in Chrome. This expanded fixture contains 30 browser DOM checks for filtering, collection, scroll restoration, and thread connectors. The prior 22-check browser suite passed for 1.0.1. The expanded browser suite was not run for 1.0.2 because the isolated preview blocked local-file navigation. The 1.0.2 patch still needs an installed-extension visual check on X.

The local checks use mocked Chrome storage or DOM adapters and do not install the extension or access X.

Chrome references: [load an unpacked extension](https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked), [content scripts](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts), and [local extension storage](https://developer.chrome.com/docs/extensions/reference/api/storage).
