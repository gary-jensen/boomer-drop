const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

// A minimal DOM adapter for the observed avatar-column layout. These tests run
// entirely in Node; they neither launch a browser nor access a live account.
class Element {
  constructor(style = {}, attrs = {}) {
    this.tagName = 'DIV'; this.style = style; this.attrs = new Map(Object.entries(attrs));
    this.children = []; this.textContent = '';
  }
  get childElementCount() { return this.children.length; }
  append(...nodes) { for (const node of nodes) { node.parentElement = this; this.children.push(node); } }
  hasAttribute(name) { return this.attrs.has(name); }
  getAttribute(name) { return this.attrs.get(name) ?? null; }
  setAttribute(name, value) { this.attrs.set(name, value); }
  removeAttribute(name) { this.attrs.delete(name); }
  closest() { return this.tagName === 'ARTICLE' ? this : this.parentElement?.closest(); }
}
function post({ before = false, after = false, excluded = false } = {}) {
  const article = new Element(); article.tagName = 'ARTICLE';
  const column = new Element(); article.append(column);
  const line = () => new Element({ width: '2px', backgroundColor: 'rgb(47, 51, 54)' });
  const incoming = before && line(), outgoing = after && line();
  const avatar = new Element({}, { 'data-testid': 'Tweet-User-Avatar' });
  if (incoming) column.append(incoming);
  column.append(avatar);
  if (outgoing) column.append(outgoing);
  article.querySelector = () => avatar;
  return { article, excluded, incoming, outgoing, column };
}
function create() {
  const context = { getComputedStyle: node => ({ width: 'auto', backgroundColor: 'rgba(0, 0, 0, 0)', ...node.style }) };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../threads.js'), 'utf8'), context);
  return context.XCircleThreads();
}
const hidden = node => node.getAttribute('data-xcircle-thread-line-hidden') === 'true';

test('hidden reply breaks the parent line before an unrelated visible post', () => {
  const parent = post({ after: true }), reply = post({ before: true, excluded: true }), unrelated = post();
  create().sync([parent, reply, unrelated]);
  assert.equal(hidden(parent.outgoing), true);
  assert.equal(parent.article.getAttribute('data-xcircle-break-after'), 'true');
  assert.equal(unrelated.article.attrs.size, 0);
});
test('hidden parent removes a surviving reply’s incoming connector', () => {
  const parent = post({ after: true, excluded: true }), reply = post({ before: true });
  create().sync([parent, reply]);
  assert.equal(hidden(reply.incoming), true);
  assert.equal(reply.article.getAttribute('data-xcircle-break-before'), 'true');
});
test('surviving adjacent thread posts keep both connectors', () => {
  const parent = post({ after: true }), reply = post({ before: true });
  create().sync([parent, reply]);
  assert.equal(hidden(parent.outgoing), false);
  assert.equal(hidden(reply.incoming), false);
  assert.equal(parent.article.attrs.size + reply.article.attrs.size, 0);
});
test('a visible middle post loses both edges when both neighbors are filtered', () => {
  const middle = post({ before: true, after: true });
  create().sync([post({ excluded: true }), middle, post({ excluded: true })]);
  assert.equal(hidden(middle.incoming), true);
  assert.equal(hidden(middle.outgoing), true);
  assert.equal(middle.article.getAttribute('data-xcircle-break-before'), 'true');
  assert.equal(middle.article.getAttribute('data-xcircle-break-after'), 'true');
});
test('recycling a hidden neighbor to a matching author restores the old edge', () => {
  const threads = create(), parent = post({ after: true }), reply = post({ excluded: true });
  threads.sync([parent, reply]);
  reply.excluded = false;
  threads.sync([parent, reply]);
  assert.equal(hidden(parent.outgoing), false);
  assert.equal(parent.article.hasAttribute('data-xcircle-break-after'), false);
});
test('turning off filtering clears all thread decorations', () => {
  const threads = create(), parent = post({ after: true }), reply = post({ excluded: true });
  threads.sync([parent, reply]); threads.clear();
  assert.equal(hidden(parent.outgoing), false);
  assert.equal(parent.article.hasAttribute('data-xcircle-break-after'), false);
});
test('media graphics, transparent spacers, and interactive controls are untouched', () => {
  const parent = post({ after: true });
  const videoLine = new Element({ width: '2px', backgroundColor: 'rgb(47, 51, 54)' });
  parent.article.append(videoLine);
  const spacer = new Element({ width: '2px', backgroundColor: 'rgba(0, 0, 0, 0)' });
  const control = new Element({ width: '2px', backgroundColor: 'rgb(47, 51, 54)' }, { role: 'slider' });
  parent.column.append(spacer, control);
  create().sync([parent, post({ excluded: true })]);
  assert.equal(hidden(parent.outgoing), true);
  for (const node of [videoLine, spacer, control]) assert.equal(hidden(node), false);
});
test('unmounted posts and thread views lose stale decoration on cleanup', () => {
  const threads = create(), parent = post({ after: true });
  threads.sync([parent, post({ excluded: true })]); threads.sync([]);
  assert.equal(hidden(parent.outgoing), false);
  assert.equal(parent.article.hasAttribute('data-xcircle-break-after'), false);
});
