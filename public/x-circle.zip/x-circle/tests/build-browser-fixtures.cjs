const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..') + path.sep;
const output = path.resolve(process.argv[2] || 'work/x-circle-browser-tests');
fs.mkdirSync(output, {recursive:true});
const mock = `
const listeners = [];
let state = {account:'owner',mode:'mutuals','snapshot:owner:following':{handles:['mutual','following']},'snapshot:owner:followers':{handles:['mutual','follower']}};
globalThis.chrome = {runtime:{onMessage:{addListener(){}}},storage:{local:{async get(){return structuredClone(state)},async set(values){Object.assign(state,values);for(const f of listeners)f({},'local')},async remove(keys){for(const k of keys)delete state[k];for(const f of listeners)f({},'local')}},onChanged:{addListener(f){listeners.push(f)}}}};
const shadowRoots=[];
const realAttach=Element.prototype.attachShadow;
Element.prototype.attachShadow=function(options){const result=realAttach.call(this,options);shadowRoots.push(result);return result};
const fakeLocation={pathname:'/home',hash:'',search:''};
function post(name,extra=''){const cell=document.createElement('div');cell.dataset.testid='cellInnerDiv';cell.innerHTML='<article data-testid="tweet"><div data-testid="User-Name"><a href="/'+name+'">'+name+'</a><a href="/'+name+'/status/1"><time>now</time></a></div>'+extra+'</article>';document.querySelector('[data-testid="primaryColumn"]').append(cell);return cell}
const mutual=post('mutual','<div data-testid="User-Name"><a href="/stranger">quoted author</a></div>');
const followingPost=post('following');const follower=post('follower');const stranger=post('stranger');
const unknown=post('unknown');unknown.querySelector('[data-testid="User-Name"]').remove();
`;
const tests = `
const results=[];const delay=()=>new Promise(r=>setTimeout(r,220));
function assert(condition,name){if(!condition)throw Error(name);results.push('PASS '+name)}
const isHidden=node=>getComputedStyle(node).display==='none';
(async()=>{
await delay();
assert(!isHidden(mutual)&&isHidden(followingPost)&&isHidden(follower)&&isHidden(stranger),'mutual-only DOM filter and quoted author');
assert(!isHidden(unknown),'unknown author stays visible');
await chrome.storage.local.set({mode:'followers-only'});await delay();
assert(!isHidden(follower)&&isHidden(mutual)&&isHidden(stranger),'followers-only filter restores matching post');
await chrome.storage.local.set({mode:'not-following'});await delay();
assert(!isHidden(follower)&&!isHidden(stranger)&&isHidden(mutual)&&isHidden(followingPost),'not-following DOM filter');
const later=post('following');await delay();assert(isHidden(later),'newly inserted posts filtered');
later.querySelector('a').setAttribute('href','/stranger');await delay();assert(!isHidden(later),'recycled author restores a hidden cell');

// Reproduce the live X layout: avatar + a narrow outgoing line, a hidden reply,
// then an unrelated visible post. Include incoming lines and a surviving thread.
function threadPost(name,before,after){
  const cell=post(name);const article=cell.querySelector('article');
  const rail=document.createElement('div');rail.className='test-rail';
  const line=direction=>'<div class="'+direction+'" style="width:2px;height:50px;background:rgb(47,51,54)"></div>';
  rail.innerHTML=(before?line('incoming'):'')+'<div data-testid="Tweet-User-Avatar"><a href="/'+name+'">avatar</a></div>'+(after?line('outgoing'):'');
  article.prepend(rail);return cell;
}
const parent=threadPost('stranger',false,true);
const removedReply=threadPost('following',true,false);
const unrelated=threadPost('stranger',false,false);
const removedParent=threadPost('following',false,true);
const keptReply=threadPost('stranger',true,true);
const keptContinuation=threadPost('stranger',true,false);
// Narrow graphics outside the avatar column must remain untouched.
const graphic=document.createElement('div');graphic.innerHTML='<div style="width:2px;height:50px;background:rgb(47,51,54)"></div>';parent.querySelector('article').append(graphic);
await delay();
assert(getComputedStyle(parent.querySelector('.outgoing')).visibility==='hidden','hidden reply removes the parent connector pointing at an unrelated post');
assert(parent.querySelector('article').getAttribute('data-xcircle-break-after')==='true','broken outgoing thread gets a divider');
assert(getComputedStyle(keptReply.querySelector('.incoming')).visibility==='hidden','hidden parent removes the orphaned incoming connector');
assert(keptReply.querySelector('article').getAttribute('data-xcircle-break-before')==='true','orphaned reply gets a divider above it');
assert(getComputedStyle(keptReply.querySelector('.outgoing')).visibility==='visible'&&getComputedStyle(keptContinuation.querySelector('.incoming')).visibility==='visible','adjacent surviving thread posts retain both connecting lines');
assert(getComputedStyle(graphic.firstElementChild).visibility==='visible','video and quote graphics outside the avatar column are untouched');
// A recycled cell can become a matching author without changing its layout.
removedReply.querySelector('[data-testid="User-Name"] a').setAttribute('href','/stranger');await delay();
assert(getComputedStyle(parent.querySelector('.outgoing')).visibility==='visible'&&!parent.querySelector('article').hasAttribute('data-xcircle-break-after'),'recycled matching reply restores the original connector and border');
await chrome.storage.local.set({mode:'off'});await delay();assert(!isHidden(mutual)&&!isHidden(followingPost),'off restores all posts');
assert(!document.querySelector('[data-xcircle-thread-line-hidden], [data-xcircle-break-before], [data-xcircle-break-after]'),'turning filtering off restores every thread decoration');
for(const cell of [parent,removedReply,unrelated,removedParent,keptReply,keptContinuation])cell.remove();
await chrome.storage.local.set({mode:'mutuals'});await delay();
document.querySelector('[data-testid="AppTabBar_Profile_Link"]').setAttribute('href','/different');await delay();assert(!isHidden(follower),'account mismatch pauses filtering');
document.querySelector('[data-testid="AppTabBar_Profile_Link"]').setAttribute('href','/owner');await delay();assert(isHidden(follower),'matching account resumes filtering');
await chrome.storage.local.remove(['snapshot:owner:followers']);await delay();assert(!isHidden(follower),'missing list pauses filtering');
await chrome.storage.local.set({'snapshot:owner:followers':{handles:['mutual']}});await delay();
fakeLocation.pathname='/owner/status/1';post('anyone');await delay();assert(!isHidden(follower),'navigation away from home restores posts');

// Model X replacing Home with a short thread, then rebuilding its virtual list.
fakeLocation.pathname='/home';
const column=document.querySelector('[data-testid="primaryColumn"]');column.innerHTML='';
const sizing=document.createElement('style');sizing.textContent='article[data-testid="tweet"] {height:160px}';document.head.append(sizing);
for(let i=0;i<70;i++){const cell=post(i%2 ? 'follower' : 'following');cell.querySelector('a[href*="/status/"]').setAttribute('href','/'+(i%2?'follower':'following')+'/status/'+(100+i));}
await chrome.storage.local.set({mode:'not-following'});await delay();
window.scrollTo(0,1500);await delay();
const anchor=[...column.querySelectorAll('article')].find(p=>{const r=p.getBoundingClientRect();return r.height>0&&r.bottom>0&&r.top<innerHeight});
const originalTop=anchor.getBoundingClientRect().top;
anchor.dispatchEvent(new MouseEvent('click',{bubbles:true}));
fakeLocation.pathname='/follower/status/119';
const homeNodes=[...column.childNodes];column.replaceChildren();post('following');
await chrome.storage.local.set({mode:'not-following'});await delay();
assert(window.scrollY<1500,'short tweet view reproduces lost Home scroll position');
fakeLocation.pathname='/home';column.replaceChildren(...homeNodes);window.scrollTo(0,0);window.dispatchEvent(new PopStateEvent('popstate'));
await new Promise(r=>setTimeout(r,450));
assert(Math.abs(anchor.getBoundingClientRect().top-originalTop)<3,'Back restores the same visible tweet after filtering');
// A late X scroll reset / image reflow must not undo restoration.
homeNodes[1].querySelector('article').style.height='260px';window.scrollTo(0,0);
await new Promise(r=>setTimeout(r,350));
assert(Math.abs(anchor.getBoundingClientRect().top-originalTop)<3,'late layout changes and X scroll resets preserve the tweet anchor');
window.dispatchEvent(new WheelEvent('wheel'));window.scrollTo(0,0);await delay();
assert(window.scrollY===0,'intentional user scrolling cancels restoration');
// A Home link visit, rather than browser Back, should still start at the top.
fakeLocation.pathname='/follower/status/119';await chrome.storage.local.set({mode:'not-following'});await delay();
fakeLocation.pathname='/home';await chrome.storage.local.set({mode:'not-following'});await delay();
assert(window.scrollY===0,'ordinary Home navigation does not restore an old position');
sizing.remove();
fakeLocation.pathname='/owner/followers';fakeLocation.hash='#xc-collect';
document.querySelector('[data-testid="primaryColumn"]').innerHTML='<section role="region"><div data-testid="UserCell"><a href="/avatar_owner">name</a><a href="/bio_mention">bio</a></div><div data-testid="UserCell"><a href="/other">other</a></div></section><aside><div data-testid="UserCell"><a href="/recommendation">suggested</a></div></aside>';
await new Promise(r=>setTimeout(r,1200));
const panel=shadowRoots.at(-1);assert(!!panel,'collector opens on requested relationship route');
assert(panel.querySelector('.count').textContent==='2 collected','collector reads account names and excludes outside recommendations');
assert(panel.querySelector('.save').disabled,'saving requires review');
panel.querySelector('.pause').click();
document.querySelector('section').insertAdjacentHTML('beforeend','<div data-testid="UserCell"><a href="/third">third</a></div>');await delay();
assert(panel.querySelector('.count').textContent==='3 collected','collector captures manually loaded accounts while paused');
panel.querySelector('input').click();panel.querySelector('.save').click();await delay();
assert(JSON.stringify(state['snapshot:owner:followers'].handles)===JSON.stringify(['avatar_owner','other','third']),'reviewed snapshot replaces previous list');
assert(panel.querySelector('.status').textContent.startsWith('Saved 3'),'save success is visible');
document.body.innerHTML='<pre id="results">'+results.join('\\n')+'\\nALL '+results.length+' BROWSER CHECKS PASSED</pre>';
})().catch(e=>{document.body.innerHTML='<pre id="results">'+results.join('\\n')+'\\nFAIL '+e.stack+'</pre>'});
`;
fs.writeFileSync(path.join(output, 'test.html'),'<!doctype html><html><head><style>'+fs.readFileSync(root+'content.css','utf8')+'</style></head><body><a data-testid="AppTabBar_Profile_Link" href="/owner">Profile</a><main data-testid="primaryColumn"></main><script>'+mock+'</script><script>'+fs.readFileSync(root+'core.js','utf8')+'</script><script>'+fs.readFileSync(root+'navigation.js','utf8')+'</script><script>'+fs.readFileSync(root+'threads.js','utf8')+'</script><script>(function(location){'+fs.readFileSync(root+'content.js','utf8')+'})(fakeLocation)</script><script>'+tests+'</script></body></html>');
let popup=fs.readFileSync(root+'popup.html','utf8').replace('<link rel="stylesheet" href="popup.css">','<style>'+fs.readFileSync(root+'popup.css','utf8')+'</style>').replace('<script src="core.js" defer></script><script src="popup.js" defer></script>','');
popup=popup.replace('</body>', '<script>document.querySelector("#account").value="your_username";document.querySelector("#status").textContent="Save your username, then collect your lists.";</script></body>');
fs.writeFileSync(path.join(output, 'popup-preview.html'),popup);

console.log('Open in Chrome: ' + path.join(output, 'test.html'));
