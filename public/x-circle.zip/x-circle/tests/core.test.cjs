const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../core.js');

test('the three filters cover all four relationship combinations', () => {
  const following = new Set(['mutual', 'following']);
  const followers = new Set(['mutual', 'follower']);
  const names = ['mutual', 'following', 'follower', 'stranger'];
  assert.deepEqual(names.filter(n => C.allows(n, 'not-following', following, followers)), ['follower', 'stranger']);
  assert.deepEqual(names.filter(n => C.allows(n, 'mutuals', following, followers)), ['mutual']);
  assert.deepEqual(names.filter(n => C.allows(n, 'followers-only', following, followers)), ['follower']);
  assert.deepEqual(names.filter(n => C.allows(n, 'off', following, followers)), names);
});
test('unreadable authors remain visible', () => {
  for (const mode of C.modes) assert.equal(C.allows(null, mode, new Set(), new Set()), true);
});
test('a missing list cannot masquerade as a verified empty list', () => {
  assert.equal(C.ready('not-following', null, null), false);
  assert.equal(C.ready('not-following', { handles: [] }, null), true);
  assert.equal(C.ready('mutuals', { handles: [] }, null), false);
  assert.equal(C.ready('followers-only', { handles: [] }, { handles: [] }), true);
});
test('normalize usernames and reject navigation, post, and external links', () => {
  assert.equal(C.handle(' @Example_1 '), 'example_1');
  assert.equal(C.profile('https://twitter.com/EXAMPLE_1/'), 'example_1');
  assert.equal(C.profile('/example_1?src=nav'), 'example_1');
  for (const value of ['/home', '/i', '/person/status/123', 'https://evil.test/person', '/person/followers']) assert.equal(C.profile(value), null);
  for (const value of ['a'.repeat(16), '@@person', 'has space', '']) assert.equal(C.handle(value), null);
});
test('list keys separate accounts and relationship types', () => {
  assert.notEqual(C.key('alice', 'following'), C.key('bob', 'following'));
  assert.notEqual(C.key('alice', 'following'), C.key('alice', 'followers'));
});
