'use strict';
const C = XCircle;
let data = {};
let activeTab;
const $ = selector => document.querySelector(selector);
const status = message => { $('#status').textContent = message; };
async function tabStatus() {
  try { return activeTab && await chrome.tabs.sendMessage(activeTab.id, { type: 'xc-status' }); }
  catch { return null; }
}
async function render() {
  data = await chrome.storage.local.get(null);
  const owner = data.account;
  if (document.activeElement !== $('#account')) $('#account').value = owner || '';
  const following = data[C.key(owner, 'following')];
  const followers = data[C.key(owner, 'followers')];
  document.querySelectorAll('[name=mode]').forEach(input => {
    input.checked = input.value === (data.mode || 'off');
    input.disabled = !C.ready(input.value, following, followers);
  });
  for (const kind of ['following', 'followers']) {
    const snapshot = data[C.key(owner, kind)];
    $(`#${kind}-count`).textContent = snapshot ? `${snapshot.handles.length.toLocaleString()} saved · ${new Date(snapshot.savedAt).toLocaleDateString()}` : 'Not collected';
    $(`[data-collect=${kind}]`).disabled = !owner;
  }
  const current = await tabStatus();
  status(!owner ? 'Save your username, then collect your lists.' : current?.message || 'Open or reload X to use your filter on the Home timeline.');
}
function safe(action) { return async event => { try { await action(event); } catch (error) { status(`Could not finish: ${error.message}`); } }; }
$('#account-form').addEventListener('submit', safe(async event => {
  event.preventDefault();
  const owner = C.handle($('#account').value);
  if (!owner) return status('Enter a valid X username, without a URL.');
  await chrome.storage.local.set({ account: owner, mode: owner === data.account ? (data.mode || 'off') : 'off' });
  await render();
}));
$('#filters').addEventListener('change', safe(async event => {
  if (C.modes.includes(event.target.value)) await chrome.storage.local.set({ mode: event.target.value });
}));
document.querySelectorAll('[data-collect]').forEach(button => button.addEventListener('click', safe(async () => {
  await chrome.tabs.create({ url: `https://x.com/${data.account}/${button.dataset.collect}#xc-collect` });
})));
$('#clear').addEventListener('click', safe(async () => {
  await chrome.storage.local.set({ mode: 'off' });
  await chrome.storage.local.remove(Object.keys(data).filter(key => key.startsWith('snapshot:')));
  await render();
  status('Saved lists cleared. Filtering is off.');
}));
chrome.storage.onChanged.addListener(() => { render().catch(error => status(error.message)); });
(async () => {
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const current = await tabStatus();
  const stored = await chrome.storage.local.get('account');
  if (!stored.account && current?.account) await chrome.storage.local.set({ account: current.account, mode: 'off' });
  await render();
})().catch(error => status(error.message));
